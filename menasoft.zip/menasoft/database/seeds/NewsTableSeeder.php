<?php

use Illuminate\Database\Seeder;

class NewsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        

        for ($i=0; $i < 3; $i++) { 
	    	DB::table('news')->insert([
	            'title' => str_random(8),
	            'short_description' => str_random(200),
	            'text' => str_random(300)
	        ]);
    	  }
    }
}

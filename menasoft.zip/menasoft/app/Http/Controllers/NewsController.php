<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\News;
use Illuminate\Support\Facades\Input;

class NewsController extends Controller
{
    public function index(Request $request,$sort='',$filter='')
    {		
    		if(!empty($sort))
    			$sort = explode(',', $sort);
    		if(!empty($filter)){
    			$filter = explode(',', $filter);
    			$filter_part1 =  explode('=', $filter[0]);
    			$filter_part2 =  explode('=', $filter[1]);
    		}
    		
        $query = \DB::table('news');
        
        if(!empty($sort[0]))
        	$query->orderBy($sort[0],'ASC');
        if(!empty($sort[1]))
        	$query->orderBy($sort[1],'ASC');
        if(!empty($filter_part1[0]))
        	$query->where($filter_part1[0],$filter_part1[1]);
        if(!empty($filter_part2[0]))
        	$query->where($filter_part2[0],$filter_part2[1]);
        $res = $query->get();
        
        return $res;
    }

    public function show($id)
    {
        $news =  News::find($id);
        
        return $news;
    }

    public function store(Request $request)
    {
        $news = News::create($request->all());

        return response()->json($news, 201);
    }

    public function update(Request $request, News $news)
    {
        $news->update($request->all());

        return response()->json($news, 200);
    }

    public function delete($id)
    {
        $news = News::find($id);
        $news->delete();

        return response()->json('success', 204);
    }

}
